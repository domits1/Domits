export const filterByGuests = (properties, guests) => {
    const guestNumber = parseInt(guests, 10);
  
    if (isNaN(guestNumber)) {
      console.warn("Invalid or missing 'guests' parameter");
      return properties; 
    }
  
    const filtered = properties.filter((p) => {
      const capacity = p?.property?.guestCapacity;
      if (typeof capacity !== "number") return true;
      return capacity >= guestNumber;
    });
  
    return filtered;
  };
  
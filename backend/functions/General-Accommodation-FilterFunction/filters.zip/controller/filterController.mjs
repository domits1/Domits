import { FilterService } from '../business/filterService.mjs';
import { ok, serverError } from '../util/responseHelper.mjs';

export class FilterController {
  constructor() {
    this.service = new FilterService();
  }

  async getFilteredProperties(event) {
    const queryParams = event.queryStringParameters || {};
    const { minPrice: min, maxPrice: max, guests, country, city } = queryParams;

    try {
      const properties = await this.service.getFilteredProperties({ min, max, guests, country, city });
      return ok(properties);
    } catch (err) {
      console.error("Error in filter controller:", err);
      return serverError("Internal Server Error", err.message);
    }
  }
}

export const filterByPrice = (properties, minPrice, maxPrice) => {
  const min = parseFloat(minPrice || "0");
  const max = parseFloat(maxPrice || "10000000");

  if (isNaN(min) || isNaN(max)) {
    console.warn("invalid price range skipping price filter.");
    return properties;
  }

  const filtered = properties.filter((p) => {
    const price = p?.propertyPricing?.roomRate;
    if (typeof price !== "number") return true;
    return price >= min && price <= max;
  });

  return filtered;
};

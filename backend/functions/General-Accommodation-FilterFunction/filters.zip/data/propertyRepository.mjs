const PROPERTIES_API_URL =
  process.env.PROPERTIES_API_URL ||
  "https://wkmwpwurbc.execute-api.eu-north-1.amazonaws.com/default/property/bookingEngine/all";

export const fetchProperties = async () => {
  try {
    const response = await fetch(PROPERTIES_API_URL);
    const raw = await response.json();
    return raw.properties;
  } catch (err) {
    console.error("error fetching properties:", err);
    throw new Error("failed to fetch properties");
  }
};
